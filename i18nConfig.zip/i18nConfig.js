const i18nConfig = {
    locales: ['en','ar'],
    defaultLocale: 'ar',
    localeDetection: true, // Enables automatic detection
  };
  
  module.exports = i18nConfig;